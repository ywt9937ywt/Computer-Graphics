#include "Bezier.h"


Bezier::Bezier(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);
    init();

    setWindowTitle(tr("Bezier"));
    resize(700, 700);
}

void Bezier::mousePressEvent(QMouseEvent* e)
{
    if (e->button() == Qt::LeftButton && control_points.length()<4)
    {
        //�������   ��ʾ��������
        QVector2D point = QVector2D(e->x(), e->y());
        control_points.append(point);
        qDebug() << "number of control point:  " << control_points.length();
        if (control_points.length() == 4) {
            //naive_bezier(control_points);
            recursive_bezier(control_points);
            repaint();
        }
    }
    if (e->button() == Qt::RightButton)
    {
        //�Ҽ�����    ��ʾ��������
        control_points.clear();
        qDebug() << "control point cleared";
    }
    
}

void Bezier::paintEvent(QPaintEvent*)
{
    QPainter painter(this);

    QImage image(WIDTH, HEIGHT, QImage::Format_RGB32);
    //painter.drawLine(QPoint(100, 100), QPoint(10, 100));
    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            image.setPixel(x,  y, array[x][y]);
            if (array[x][y] == qRgb(255, 0, 0)) {
                qDebug() << "1";
            }
        }
    }
    painter.drawImage(10, 10, image);
}

void Bezier::init()
{
    array = new QRgb * [WIDTH];
    for (int x = 0; x < WIDTH; x++) {
        array[x] = new QRgb[HEIGHT]; // need to delete
    }
}

void Bezier::naive_bezier(const QVector<QVector2D>& points)
{
    auto& p_0 = points[0];
    auto& p_1 = points[1];
    auto& p_2 = points[2];
    auto& p_3 = points[3];

    for (double t = 0.0; t <= 1.0; t += 0.001)
    {
        auto point = std::pow(1 - t, 3) * p_0 + 3 * t * std::pow(1 - t, 2) * p_1 +
            3 * std::pow(t, 2) * (1 - t) * p_2 + std::pow(t, 3) * p_3;

        //window.at<cv::Vec3b>(point.y, point.x)[2] = 255;
        array[(int)point.x()][(int)point.y()] = qRgb(0, 0, 0);
        /*qDebug() << point.x() << "   " << point.y();
        break;*/
    }


    repaint();
}

void Bezier::recursive_bezier(const QVector<QVector2D>& control_points)
{
    for (float t = 0; t < 1;) {
        // TODO: Implement de Casteljau's algorithm
        QVector<QVector2D> control_points1;
        QVector<QVector2D> control_points2;
        for (int i = 0; i < control_points.length() - 1; i++) {
            QVector2D p = control_points[i] + t * (control_points[i+1] - control_points[i]);
            control_points1.append(p);
            control_points2.append(p);
        }
        while (control_points2.length() != 1) {
            control_points2.clear();
            for (int i = 0; i < control_points1.length() - 1; i++) {
                QVector2D p = control_points1[i] + t * (control_points1[i + 1] - control_points1[i]);
                control_points2.append(p);
            }
            control_points1.clear();
            for (int i = 0; i < control_points2.length(); i++) {
                control_points1.append(QVector2D(control_points2[i]));
            }
        }
        if (control_points2.length() == 1) {
            array[(int)control_points2[0].x()][(int)control_points2[0].y()] = qRgb(0, 0, 0);
        }
        t += 0.001;
    }
    
    
}