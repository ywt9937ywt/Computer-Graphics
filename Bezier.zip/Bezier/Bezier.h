#pragma once

#include <QtWidgets/QWidget>
#include <QMouseEvent>
#include <QtGui>
#include <QDebug>
#include "ui_Bezier.h"

#define HEIGHT 600
#define WIDTH 600

class Bezier : public QWidget
{
    Q_OBJECT

public:
    Bezier(QWidget *parent = Q_NULLPTR);

protected:
    void mousePressEvent(QMouseEvent* e);
    void paintEvent(QPaintEvent*);

private:
    void init();
    void naive_bezier(const QVector<QVector2D>& points);
    void recursive_bezier(const QVector<QVector2D>& control_points);

private:
    Ui::BezierClass ui;
    QVector<QVector2D> control_points;
    QRgb** array;
};
